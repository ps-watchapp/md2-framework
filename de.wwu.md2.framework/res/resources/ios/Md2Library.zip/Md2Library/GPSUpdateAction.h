// static: Actions
//
//  GPSAction.h
//  TariffCalculator
//
//  Created by Uni Münster on 06.08.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Action.h"
#import "GPSUpdateEvent.h"

@interface GPSUpdateAction : Action
@end