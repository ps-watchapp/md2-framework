// static: Actions
//
//  ValidatorUnbindingAction.h
//  TariffCalculator
//
//  Created by Uni Münster on 26.06.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Action.h"
#import "ValidatorUnbindingEvent.h"

@interface ValidatorUnbindingAction : Action
@end