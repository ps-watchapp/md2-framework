// static: Validators
//
//  NumberValidator.h
//  Tarifrechner
//
//  Created by Uni Münster on 24.05.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Validator.h"

@interface IntegerValidator : Validator
@end