// static: Actions
//
//  LoadAction.h
//  TariffCalculator
//
//  Created by Uni Münster on 02.07.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Action.h"
#import "LoadEvent.h"

@interface LoadAction : Action
@end