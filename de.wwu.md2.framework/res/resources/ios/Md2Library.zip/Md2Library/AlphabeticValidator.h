// static: Validators
//
//  AlphabeticValidator.h
//  TariffCalculator
//
//	The AlphabeticValidator encapsulates the validation of alphabetic strings.
//
//  Created by Uni Muenster on 24.05.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Validator.h"

@interface AlphabeticValidator : Validator
@end