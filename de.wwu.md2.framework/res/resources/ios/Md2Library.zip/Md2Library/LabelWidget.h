// static: Widgets
//
//  LabelWidget.h
//  TariffCalculator
//
//  Created by Uni Münster on 05.06.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Widget.h"

@interface LabelWidget : Widget
{
    NSString *displayText;
}

@end