// static: Actions
//
//  ShowCustomPickerControllerAction.h
//  TariffCalculator
//
//  Created by Uni Münster on 17.06.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Action.h"
#import "ShowCustomPickerControllerEvent.h"

@interface ShowCustomPickerControllerAction : Action
@end