//
//  ContentProviderSingle.h
//  Md2Library
//
//  Created by Student LS-PI on 04.07.13.
//
//

#import <Foundation/Foundation.h>
#import "ContentProvider.h"

@interface ContentProviderSingle : ContentProvider
{
    //NSManagedObject *currentDataObject;
}

@end
