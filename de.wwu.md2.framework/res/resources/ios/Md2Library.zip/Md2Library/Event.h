// static: Events
//
//  Event.h
//  TariffCalculator
//
//  Created by Uni Münster on 04.06.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

@interface Event : NSObject

+(id) event;

@end