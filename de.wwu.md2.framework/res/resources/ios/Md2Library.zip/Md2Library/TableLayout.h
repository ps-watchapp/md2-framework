// static: Layouts
//
//  TableView.h
//  TariffCalculator
//
//  Created by Uni Münster on 01.06.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Layout.h"

@interface TableLayout : Layout
@end