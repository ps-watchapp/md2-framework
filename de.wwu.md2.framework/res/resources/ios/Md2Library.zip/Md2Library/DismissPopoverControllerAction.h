// static: Actions
//
//  DismissPopoverControllerAction.h
//  TariffCalculator
//
//  Created by Uni Münster on 17.06.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Action.h"
#import "DismissPopoverControllerEvent.h"

@interface DismissPopoverControllerAction : Action
@end