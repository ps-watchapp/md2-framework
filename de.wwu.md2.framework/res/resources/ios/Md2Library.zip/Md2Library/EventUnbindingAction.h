// static: Actions
//
//  EventUnbindingAction.h
//  TariffCalculator
//
//  Created by Uni Münster on 25.06.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Action.h"
#import "EventUnbindingEvent.h"

@interface EventUnbindingAction : Action
@end