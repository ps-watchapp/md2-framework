// static: Actions
//
//  CreateAction.h
//  TariffCalculator
//
//  Created by Uni Münster on 06.08.12.
//  Copyright (c) 2012 Uni-Muenster. All rights reserved.
//

#import "Action.h"
#import "CreateEvent.h"

@interface CreateAction : Action
@end